# 🇫🇷 French C1 Mission — 40-Day Dashboard

A complete free self-study dashboard to take your French from 0 to C1 (targeting CLB 7+ on TCF/TEF Canada) in 40 days at 8 hours/day.

## 🚀 Host on GitHub Pages (Free)

1. Create a new GitHub repository (e.g. `french-c1-mission`)
2. Upload all files maintaining the folder structure:
   ```
   index.html
   css/style.css
   js/data.js
   js/app.js
   README.md
   ```
3. Go to **Settings → Pages**
4. Under **Source**, select `main` branch and `/ (root)` folder
5. Click **Save** — your site will be live at `https://yourusername.github.io/french-c1-mission`

## 📁 File Structure

```
french-c1-dashboard/
├── index.html          ← Main dashboard (all pages)
├── css/
│   └── style.css       ← All styling
├── js/
│   ├── data.js         ← All content data (syllabus, prompts, tests)
│   └── app.js          ← All interactivity
└── README.md
```

## ✨ Features

- **Dashboard** — Day tracker, phase overview, 40-day calendar, progress bar
- **Syllabus** — Day-by-day curriculum for all 4 phases
- **Schedule** — Detailed hourly timetable for each phase
- **Vocabulary** — Topic clusters, free resource links, daily targets
- **Grammar** — Full checklist by phase + free resource links
- **Listening** — Curated free podcasts and YouTube channels
- **Reading** — Graded sources with reading technique protocol
- **Writing** — TCF format guide, writing prompts generator
- **Speaking** — TCF topic generator by CEFR level
- **Mock Exams** — Reading comprehension mini-tests + free external resource links + CLB score mapping
- **Progress** — Score logger, skill history, radar chart, daily notes

## 🗓 Study Plan Summary

| Phase | Days | Focus | Hours/Day |
|-------|------|-------|-----------|
| 1 | 1–4 | Tenses, grammar, core vocab | 8h |
| 2 | 5–14 | Reading + Writing + Listening + Speaking (2h each) | 8h |
| 3 | 15–24 | 4h skills + 4h exam practice | 8h |
| 4 | 25–40 | 4h full mock exams + 4h consolidation | 8h |

**Total: 320 hours · Target: C1 (floor: B2 / CLB 7)**

## 💾 Data Persistence

All progress (current day, completed days, scores, notes) is saved to your browser's `localStorage`. Data persists across sessions on the same device/browser.

## 🔧 Customization

Edit `js/data.js` to:
- Add your own writing prompts
- Add more speaking topics
- Add more mini-test questions
- Adjust the schedule blocks

Edit `css/style.css` to change the visual theme.

## 🆓 All Resources Are Free

Every resource linked in this dashboard is 100% free:
- Anki (free app + free decks)
- Lawless French, Kwiziq (free tier)
- RFI Journal en Français Facile
- Inner French Podcast
- Easy French (YouTube)
- TV5Monde
- LanguageTool.org
- iTalki Language Partners (free exchange)
- Pimsleur via Libby (free with library card)
- TCF/TEF practice via YouTube and Internet Archive

---

**Bonne chance. 40 jours. C'est parti.** 🎯
